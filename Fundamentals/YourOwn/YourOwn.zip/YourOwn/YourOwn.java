public class YourOwn {
    public static void main(String[] args) {
        System.out.println("My name is Lee");
        System.out.println("I am 33 years old");
        System.out.println("My hometown is Shalimar, Fl");
    }
}