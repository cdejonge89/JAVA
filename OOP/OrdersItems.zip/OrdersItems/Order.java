import java.util.ArrayList;
// create the order class with the member variables listed above
class Order {
    public String name;
    public double total;
    public boolean ready;
    // default if nothing assigned
    public ArrayList<Items> items = new ArrayList<Items>();


}